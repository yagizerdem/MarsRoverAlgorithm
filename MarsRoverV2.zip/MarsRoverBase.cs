﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MarsRoverv4
{
    internal abstract class MarsRoverBase
    {

        private int x;
        private int y;


        public int X { get; set; }
        public int Y { get; set; }



        public Direction direction;



        public abstract void Move(string a);

        public abstract void Turn(string a);

        public static MarsRoverBase RoverType(int a)
        {
            if (a == 1)
            {
                return new RoverGama();
            }
            else
            {
                throw new Exception("hatalı rover girdiniz.");
            }
        }


        public void baslangicKordinatAtama(int a, int b, Direction c)
        {
            this.X = a;
            this.Y = b;
            this.direction = c;


        }

        public void getcoordinates()
        {
            Console.WriteLine(this.X);
            Console.WriteLine(this.Y);
        }

    }
}
