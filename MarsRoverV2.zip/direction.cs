﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsRoverv4
{
   

        public enum Direction 
        {
            KD = 1,
            GD = 2, 
            GB = 3,
            KB = 4, 
        }


        public enum way
    {
        R = 0,  
        L = 1,   
    }


    }

