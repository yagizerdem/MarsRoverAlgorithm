﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MarsRoverv4
{
    internal static class Plato
    {

        static int X;

        static int Y;

        public static void CreatePlato(string a)
        {
            string[] platoboytulari = a.Split(" ");

            X = Convert.ToInt16(platoboytulari[0]);

            Y = Convert.ToInt16(platoboytulari[1]);

        }

    }
}
