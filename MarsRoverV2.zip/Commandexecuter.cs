﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsRoverv4
{
    internal class Commandexecuter
    {
        public void CommandExecuter(string a, MarsRoverBase temporarayrover)
        {
            MarsRoverBase rover = temporarayrover;


            string[] commands = a.Split(" ");
            for (int i = 0; i < commands.Length; i++)
            {
                if (commands[i] != "M" &&    commands[i] != "R" && commands[i] != "L")
                {
                    throw new Exception("hatalı yön girdiniz");
                }
                else if (commands[i] == "M")
                {
                    rover.Move(rover.direction.ToString());
                }
                else if (commands[i] == "R")
                {
                    rover.Turn("R");
                }
                else if (commands[i] == "L")
                {
                    rover.Turn("L");
                }


            }
        }
    }
}
