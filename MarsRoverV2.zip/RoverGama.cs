﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace MarsRoverv4
{
    internal class RoverGama : MarsRoverBase
    {

        public override void Move(string a)
        {
            if (a == Direction.KD.ToString()) { this.X++; this.Y++; }
            if (a == Direction.KB.ToString()) { this.X--; this.Y++; }
            if (a == Direction.GD.ToString()) { this.X++; this.Y--; }
            if (a == Direction.GB.ToString()) { this.X--; this.Y--; }
        }
        public override void Turn(string a)
        {
            if (a == way.R.ToString())
            {
                if (direction == Direction.KB)
                {
                    direction = Direction.KD;
                }
                else
                {
                    direction++;
                }
            }

            if (a == way.L.ToString())
            {
                if (direction == Direction.KD)
                {
                    direction = Direction.KB;
                }
                else
                {
                    direction--;
                }
            }
        }



    }
}
