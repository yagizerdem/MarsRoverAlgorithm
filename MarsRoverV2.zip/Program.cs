﻿namespace MarsRoverv4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("plato boyutlarını giriniz");
            string platoboyutlari = Console.ReadLine();
            
            Plato.CreatePlato( platoboyutlari);


            Console.WriteLine("rover tipini giriniz");
            int RoverTipi = Convert.ToInt32(Console.ReadLine());
            MarsRoverBase denemeRoveri = MarsRoverBase.RoverType(RoverTipi);

            Console.WriteLine("başlangıç kordinatlarını girniz");
            string starter = Console.ReadLine();
            string[] starterkoordinates = starter.Split(" ");
            denemeRoveri.baslangicKordinatAtama(Int16.Parse(starterkoordinates[0]), Int16.Parse(starterkoordinates[1]), (Direction)Enum.Parse(typeof(Direction), starterkoordinates[2]));

            Console.WriteLine("işlemleri giriniz");
            string istemler = Console.ReadLine();
            Commandexecuter commands = new Commandexecuter();
            commands.CommandExecuter(istemler, denemeRoveri);



            denemeRoveri.getcoordinates();

            Console.ReadLine();
           

        }

    }
}