﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _70_MarsRoverv2
{
    internal abstract class CommandExecuterBase
    {

        public abstract void Execute(string command);
    }
}
