﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _70_MarsRoverv2
{
    internal class RowerFactory
    {
        public static RowerBase CreateRowerById(int id)
        {

            if (id == 1)
            {
                return new RowerAlfa();
            }
            else if (id == 2)
            {
                return new RoweBeta();
            }


            throw new Exception("invalid id");

        }
    }
}
