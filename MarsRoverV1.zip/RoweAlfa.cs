﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _70_MarsRoverv2
{
    internal class RowerAlfa : RowerBase
    {

        public RowerAlfa() { }


        public RowerAlfa(Plataue plataue, int x, int y, Direction direction)
        {
            this.Plataue = plataue;
            this.X = x;
            this.Y = y;
            this.Direction = direction;

        }

        /// <summary>
        /// 1 2 N olarak gelen command string i parcalayıp ilgili rowerın c y ve direction parametrelerine set eder..
        /// </summary>
        /// <param name="command"></param>





        public override void Move()
        {
            switch (this.Direction)
            {
                case Direction.N:
                    this.Y++;
                    break;
                case Direction.E:
                    this.X++;
                    break;
                case Direction.S:
                    this.Y--;
                    break;
                case Direction.W:
                    this.X--;
                    break;
                default:
                    break;
            }
        }

        public override void Turn(Way direction)
        {
            if (direction == Way.R)
            {

                if (this.Direction == Direction.W)
                {
                    this.Direction = Direction.N;

                }
                else
                    this.Direction++;

            }
            else
            {

                if (this.Direction == Direction.N)
                {
                    this.Direction = Direction.W;

                }
                else
                    this.Direction--;

            }
        }
    }
}
