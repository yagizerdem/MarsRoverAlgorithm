﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _70_MarsRoverv2
{
    //LMRM
    internal class MoveCommandExecuter : CommandExecuterBase
    {

        private const int A = 20;

        private readonly RowerBase _rower;//ilk değer almak zorunda değil
        public MoveCommandExecuter(RowerBase rower)
        {
            _rower = rower;//constructor içinde değer atanabilir. sonrasında değiştirelemez.
                           //A = 203; const sabittir değiştirelemez. ilk değer atamasını alır oylede kalır.

        }


        public override void Execute(string command)
        {

            for (int i = 0; i < command.Length; i++)
            {
                string cmd = command[i].ToString();

                if (!(cmd == Way.L.ToString() || cmd == Way.R.ToString() || cmd == Action.M.ToString())) throw new Exception("Invalid command");


                if (cmd == Way.L.ToString())
                {

                    _rower.Turn(Way.L);
                }else if(cmd == Way.R.ToString())
                {
                    _rower.Turn(Way.R);

                }else if(cmd==Action.M.ToString())
                {
                    _rower.Move();
                }
            }
        }
    }
}
