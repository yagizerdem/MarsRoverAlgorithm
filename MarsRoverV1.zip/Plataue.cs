﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _70_MarsRoverv2
{
    internal class Plataue
    {
        public int X { get; set; }

        public int Y { get; set; }

        public static Plataue CreateWithCommand(string commad)
        {

            if (commad.Length > 3)
            {
                throw new Exception("Invalid command");
            }


            string[] boyutlar = commad.Split(' ');

            int platoX = Convert.ToInt32(boyutlar[0]);
            int platoY = Convert.ToInt32(boyutlar[1]);

            return new Plataue { X = platoX, Y = platoY };

        }
    }
}
