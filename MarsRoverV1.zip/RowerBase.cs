﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _70_MarsRoverv2
{
    internal abstract class RowerBase
    {

        protected int _x;
        protected int _y;

        public Plataue Plataue {
            get;

            set; 
             
        }

        public int X
        {
            get
            {
                return _x;
            }
            set
            {
                if (value < 0 || value > Plataue.X) throw new Exception("Bu noktaya gidemem");

                _x = value;
            }
        }


        public int Y
        {
            get
            {
                return _y;
            }
            set
            {

                if (value < 0 || value > Plataue.Y) throw new Exception("Bu noktaya gidemem");

                _y = value;
            }
        }


        public Direction Direction { get; set; }

        public abstract void Move();


        public  void InitCommand(string command)
        {

            string[] rowerInits = command.Split(' ');

            int x = Convert.ToInt32(rowerInits[0]);
            int y = Convert.ToInt32(rowerInits[1]);

            Direction direction = (Direction)Enum.Parse(typeof(Direction), rowerInits[2]);

            this.X = x;
            this.Y = y;
            this.Direction = direction;
        }

        public abstract void Turn(Way direction);

        public override string ToString()
        {
            return $"{this.X} - {this.Y} - {this.Direction}";
        }
    }
}
