﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _70_MarsRoverv2
{
    internal enum Direction
    {
        N,
        E,
        S,
        W

    }

    public enum Way
    {
        //
        /// <summary>
        /// left
        /// </summary>
        L,
        //
        /// <summary>
        /// rigth
        /// </summary>
        R
    }

    public enum Action
    {
        //move
        M
    }
}
