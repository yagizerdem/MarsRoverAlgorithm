﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _70_MarsRoverv2
{
    internal class RoweBeta : RowerBase
    {
 

        public override void Move()
        {
            
            switch (this.Direction)
            {
                case Direction.N:
                    this.Y += 2;
                    break;
                case Direction.E:
                    this.X += 2;
                    break;
                case Direction.S:
                    this.Y -= 2;
                    break;
                case Direction.W:
                    this.X -= 2;
                    break;
                default:
                    break;
            }
        }

        public override void Turn(Way direction)
        {
            if (direction == Way.R)
            {

                if (this.Direction == Direction.W)
                {
                    this.Direction = Direction.N;

                }
                else
                    this.Direction++;

            }
            else
            {

                if (this.Direction == Direction.N)
                {
                    this.Direction = Direction.W;

                }
                else
                    this.Direction--;

            }
        }
    }
}
