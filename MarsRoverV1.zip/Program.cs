﻿using System.Data.Common;
using System.Runtime.InteropServices.ObjectiveC;

namespace _70_MarsRoverv2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hangi rowerla iletişim kuracaksın .\n 1 - roweralfa \n 2 rowebeta");

            int rowerType = Convert.ToInt32(Console.ReadLine());

            RowerBase rower = RowerFactory.CreateRowerById(rowerType);


            

            bool kontrol1 = (rower is RoweBeta);
            bool kontrol2 = (rower is RowerBase);
            bool kontrol3 = (rower is Math);
            bool kontrol4 = (rower is Object);


            Console.WriteLine("Platonun boyutklarını gir:");

            string platoBoyut = Console.ReadLine();


            

            Plataue plataue = Plataue.CreateWithCommand(platoBoyut);
            rower.Plataue = plataue;



            Console.WriteLine("Rower Başlangıç kordinatlarını gir:");

            string rowerInit = Console.ReadLine();


            rower.InitCommand(rowerInit);



            Console.WriteLine("Harekrtleri gir :");

            string hareketler = Console.ReadLine();

            MoveCommandExecuter moveCommandExecuter = new MoveCommandExecuter(rower);
            moveCommandExecuter.Execute(hareketler);


            Console.WriteLine(rower.ToString());
            Console.ReadLine();
        }
    }
}